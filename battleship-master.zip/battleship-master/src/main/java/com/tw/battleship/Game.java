package com.tw.battleship;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Game {

	Player player1, player2;

	public static void main(String[] args) {
		PrintStream console = System.out;
		List<String> input = new ArrayList<String>();

		// Get file from resources folder
		ClassLoader classLoader = ClassLoader.getSystemClassLoader();
		String fileName = "input.txt";
		if (classLoader.getResource(fileName) != null) {
			fileName = classLoader.getResource(fileName).getFile();
		}
		File file = new File(fileName);

		try (Scanner scanner = new Scanner(file)) {
			while (scanner.hasNextLine()) {
				input.add(scanner.nextLine());
			}
			scanner.close();
		} catch (IOException e) {
			log.error("Error while reading from file", e);
		}

		for (String string : input) {
			console.println(string);
		}

		Game game = new Game();
		game.startGame(input, console);

	}

	public void startGame(List<String> input, PrintStream ps) {
		player1 = new Player("Player-1");
		player2 = new Player("Player-2");

		player1.createBattleArea(input.get(0));
		player2.createBattleArea(input.get(0));

		addShipsToBattleArea(input);

		player1.addMissile(input.get(input.size() - 2));
		player2.addMissile(input.get(input.size() - 1));

		play(ps);
	}

	
	public void addShipsToBattleArea(List<String> input) {
	
		int totalShips = new Integer(input.get(1));
		player1.addTotalShipsToBattleArea(totalShips);
		player2.addTotalShipsToBattleArea(totalShips);

		for (int i = 0; i < totalShips; i++) {
			String[] battleShipDetail = input.get(i + 2).split(" ");
			player1.addShipInBattleArea(battleShipDetail[0], new Integer(battleShipDetail[1]),
					new Integer(battleShipDetail[2]), battleShipDetail[3]);
			player2.addShipInBattleArea(battleShipDetail[0], new Integer(battleShipDetail[1]),
					new Integer(battleShipDetail[2]), battleShipDetail[4]);
		}

	}

	void play(PrintStream ps) {

		boolean win = false;
		while (!win) {

			if (shootUntil(player1, player2, ps)) {
				break;
			}

			if (shootUntil(player2, player1, ps)) {
				break;
			}

		}
	}

	private boolean shootUntil(Player playerA, Player playerB, PrintStream ps) {
		boolean win = false;
		if (playerA.getMissiles().size() == 0) {
			ps.println(playerA.getPlayerName() + " has no more missiles left to launch");
		} else {
			boolean hit = true;
			while (hit && playerA.getMissiles().size() > 0) {
				hit = playerA.shoot(playerB, ps);
				if (playerB.isDown()) {
					ps.println(playerA.getPlayerName() + " won the battle");
					win = true;
					break;
				}
			}
		}
		return win;
	}

}
